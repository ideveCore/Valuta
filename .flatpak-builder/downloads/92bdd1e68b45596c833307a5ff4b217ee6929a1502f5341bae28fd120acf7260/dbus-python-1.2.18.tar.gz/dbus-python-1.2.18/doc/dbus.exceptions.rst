dbus.exceptions module
----------------------

.. automodule:: dbus.exceptions
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
