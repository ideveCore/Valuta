dbus.gi\_service module
-----------------------

.. automodule:: dbus.gi_service
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
