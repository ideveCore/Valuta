dbus.connection module
======================

.. automodule:: dbus.connection
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
