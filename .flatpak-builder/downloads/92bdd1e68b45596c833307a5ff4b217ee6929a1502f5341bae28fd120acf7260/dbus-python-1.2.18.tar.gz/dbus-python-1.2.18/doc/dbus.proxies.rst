dbus.proxies module
-------------------

.. automodule:: dbus.proxies
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
