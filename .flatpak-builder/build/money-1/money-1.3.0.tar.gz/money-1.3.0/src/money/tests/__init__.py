"""
Money unittests

Run with:
$ python -m unittest

"""