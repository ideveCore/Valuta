# -*- coding: utf-8 -*-
"""
Money unittests

Run with:
$ python -m unittest

"""